/*
 * Copyright © 2018 Dennis Schulmeister-Zimolong
 * 
 * E-Mail: dhbw@windows3.de
 * Webseite: https://www.wpvs.de/
 * 
 * Dieser Quellcode ist lizenziert unter einer
 * Creative Commons Namensnennung 4.0 International Lizenz.
 */
package dhbwka.wwi.vertsys.javaee.jtodo.web;

import dhbwka.wwi.vertsys.javaee.jtodo.ejb.ValidationBean;
import dhbwka.wwi.vertsys.javaee.jtodo.ejb.UserBean;
import dhbwka.wwi.vertsys.javaee.jtodo.jpa.User;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet(urlPatterns = {"/app/user/"})
public class ModifyServlet extends HttpServlet {
    
    @EJB
    ValidationBean validationBean;
            
    @EJB
    UserBean userBean;
    
    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setAttribute("edit", true);

        if (request.getSession().getAttribute("signup_form") == null) {
            // Keine Formulardaten mit fehlerhaften Daten in der Session,
            // daher Formulardaten aus dem Datenbankobjekt übernehmen
            request.setAttribute("signup_form", this.createUserForm());
}
        // Anfrage an dazugerhörige JSP weiterleiten
        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/login/user_edit.jsp");
        dispatcher.forward(request, response);
        
        // Alte Formulardaten aus der Session entfernen
        HttpSession session = request.getSession();
        session.removeAttribute("signup_form");
    }
    
    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Formulareingaben auslesen
        request.setCharacterEncoding("utf-8");
        
        String username = request.getParameter("signup_username");
        String password1 = request.getParameter("signup_password1");
        String password2 = request.getParameter("signup_password2");
        String name = request.getParameter("signup_name");
        String strasse = request.getParameter("signup_strasse");
        String email = request.getParameter("signup_email");
        String ort = request.getParameter("signup_ort");
        String plz = request.getParameter("signup_plz");
        String telefon = request.getParameter("signup_telefon");
        
        
        
        // Eingaben prüfen
        User user = new User(username, password1, name,  strasse, plz, ort , telefon, email);
        
        List<String> errors = this.validationBean.validate(user);
        this.validationBean.validate(user.getPassword(), errors);
        
        if (password1 != null && password2 != null && !password1.equals(password2)) {
            errors.add("Die beiden Passwörter stimmen nicht überein.");
        }
        
        // Neuen Benutzer anlegen
        if (errors.isEmpty()) {
            try {
                this.userBean.signup(username, password1, name,  strasse, plz, ort , telefon, email);
            } catch (UserBean.UserAlreadyExistsException ex) {
                errors.add(ex.getMessage());
            }
        }
        
        // Weiter zur nächsten Seite
        if (errors.isEmpty()) {
            // Keine Fehler: Startseite aufrufen
            request.login(username, password1);
            response.sendRedirect(WebUtils.appUrl(request, "/app/tasks/"));
        } else {
            // Fehler: Formuler erneut anzeigen
            FormValues formValues = new FormValues();
            formValues.setValues(request.getParameterMap());
            formValues.setErrors(errors);
            
            HttpSession session = request.getSession();
            session.setAttribute("signup_form", formValues);
            
            response.sendRedirect(request.getRequestURI());
        }
    }
    
    private FormValues createUserForm() {
        User currentUser = userBean.getCurrentUser();
        Map<String, String[]> values = new HashMap<>();

        values.put("signup_username", new String[]{
            currentUser.getUsername()
        });

        values.put("signup_name", new String[]{currentUser.getName() 
        });

        values.put("signup_strasse", new String[]{currentUser.getStrasse()
        });

        values.put("signup_plz", new String[]{currentUser.getPlz()
        });

        values.put("signup_ort", new String[]{currentUser.getOrt()
        });

        values.put("signup_telefonnummer", new String[]{currentUser.getTelefon()
        });
        
        values.put("signup_email", new String[]{currentUser.getEmail()
        });

        

        FormValues formValues = new FormValues();
        formValues.setValues(values);
        return formValues;
    }
    
}